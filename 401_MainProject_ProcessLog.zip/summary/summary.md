# Submission Summary -- Systems Thinking and Open Science
_Generated 2026-11-27T12:48:07.361773 | schema v3_

## Log Counts
- Check-ins: **8**
- Process logs: **7**
- Check-outs: **4**
- Total: **19**

## Session Pairing (exact session_id match)
- Complete check-in/check-out pairs: **4**
- Check-ins with no matching check-out: 20260830_170555, 20260907_173808, 20261018_165418, 20261019_185818

## Input Activity
- Avg inputs per process log: **1.43**
- Avg inputs per session: **1.43**
- Sessions with at least one process log: 7

## Self-Reported Scales (checkout)
- confidence: avg **4.5** (4/4 answered)
- clarity: avg **4.75** (4/4 answered)
- support: avg **5.0** (4/4 answered)

## Short Responses (< 20 chars)
- Total short entries: **38**
  - checkin.planned_duration: 8
  - checkin.checkin_notes: 6
  - inputlog.intent: 1
  - inputlog.own_understanding: 4
  - inputlog.reflection_outcome: 1
  - inputlog.reflection_errors: 5
  - inputlog.reflection_surprises: 6
  - checkout.duration_actual: 1
  - checkout.final_thoughts: 3
  - checkout.next_start: 3

## Longest Entries (per field)
- **checkin.goal** (181 chars, session_20260914_192945_checkin.json): I am hoping to complete my MP2 assignment by using AI to help me create the code for MATLAB. I will be giving a very specific prompt, so it is not generating any extra information. 
- **checkin.planned_duration** (11 chars, session_20260928_185407_checkin.json): 30 minutes 
- **checkin.checkin_notes** (191 chars, session_20260901_132411_checkin.json): I am interested in this because I am trying to figure out what types of yarn I should look at buying for new projects and I want to make sure I am getting the right ones so my projects last. 
- **inputlog.intent** (283 chars, session_20260901_132411_inputlog_1.json): I am trying to learn more about the different types of yarn that can be used for knitting and crocheting. I am then hoping to be able to use the knowledge to allow me to look for different companies t... [truncated, 283 chars total]
- **inputlog.own_understanding** (255 chars, session_20260901_132411_inputlog_1.json): I know that there are different types of yarn and that they each have different properties. I am hoping the LLM will help me understand those properties and them help me determine which type of yarn w... [truncated, 255 chars total]
- **inputlog.reflection_outcome** (232 chars, session_20260901_132411_inputlog_1.json): I was able to learn about different types of yarn and actually learned that there are more than I originally thought. I was also about to see about what yarn would be most helpful for the type of wear... [truncated, 232 chars total]
- **inputlog.reflection_errors** (111 chars, session_20260901_132411_inputlog_1.json): The LLM did not miss anything. The questions I asked were fairly simple which allowed it to answer thoroughly. 
- **inputlog.reflection_surprises** (164 chars, session_20260901_132411_inputlog_1.json): I was surprised with the list the LLM provided of the different types of yarns and their properties right away rather than me having to ask about properties later. 
- **checkout.duration_actual** (83 chars, session_20260901_132411_checkout.json): This took about as long as I thought it would. The process did seem a little slow. 
- **checkout.final_thoughts** (150 chars, session_20260901_132411_checkout.json): I was able to determine the type of yarn I am going to use for my next project. I am curious about how different types of yarn will affect amigurumi. 
- **checkout.next_start** (209 chars, session_20260901_132411_checkout.json): It would be helpful to think about all the different projects I would like to make and think about if there were a price point, I would like to stick to when it comes to looking at how expensive each ... [truncated, 209 chars total]

**Longest reflection overall** (508 chars, session_20260901_132411_inputlog_1.json): I was able to learn about different types of yarn and actually learned that there are more than I originally thought. I was also about to see about what yarn would be most helpful for the type of wear... [truncated, 508 chars total]

## Notes
- Abandoned/incomplete input logs (started but never finished via Finish & Reflect) are not saved to disk and cannot be counted from exported files.
- Check-in/check-out pairing uses exact session_id match only; the app assigns session_id per app-launch, not per logical work session, so a restart between check-in and check-out produces an unmatched pair even for a continuous work session.
